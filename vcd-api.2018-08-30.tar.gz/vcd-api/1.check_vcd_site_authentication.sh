#!/bin/bash


. "$(dirname "$0")/fcv3.lib"
