#! /bin/bash

echo "Linux distributions:
  - rhel:     ocp.extra_report.licence=REDHSMAL
  - centos:   ocp.extra_report.licence=CENTOS
  - debian:   ocp.extra_report.licence=DEBIAN
  - ubuntu:   ocp.extra_report.licence=UBUNTU
Windows OS:
  - enterprise edition:   ocp.extra_report.licence = WINEE
  - standard edition:     ocp.extra_report.licence = WINSTD
  - web edition:          ocp.extra_report.licence = WINWEB"
