#!/bin/bash


template_name=$(whiptail --noitem --title "Choose a template" --menu "" 25 80 18 $(
+()
{ 
    echo "$1" "$1"
} 
. template.list) 3>&1 1>&2 2>&3)


+()
{
    if [ "$template_name" = "$1" ]
    then
	    template_name="$1"

	    . "$(dirname "$0")/fcv3.lib"

	    echo "template_name: $template_name"

            dl_ovf_template "$template_name" "debug"
            transfer_ovf_template "$template_name" "$template_name"
    fi
}
. template.list
