#!/bin/bash

echo_error() {
    echo -e "\\033[1;31m""Error: $@""\\033[0;39m" >&2
}

echo_emphasis() {
    echo
    echo -e "\\033[1;32m""$@""\\033[0;39m" >&2
}


echo
if [[ -z "$VCD_SITE" ]] ; then
  echo_error "No site selected.\nTo select a site please export the VCD_SITE environment variable (see below)."
else
  echo_emphasis "Selected site is : $VCD_SITE"
  echo "To select another site please export the VCD_SITE environment variable (see below)."
fi


echo '
export VCD_SITE="apacboost.hongkong.cloud-provider"
export VCD_SITE="apacboost.singapore.cloud-provider"
export VCD_SITE="apacboost.sydney.1.northryde.cloud-provider"
export VCD_SITE="apacboost.sydney.2.alexandria.cloud-provider"
export VCD_SITE="fca2.val-de-reuil"
export VCD_SITE="fca.rueil-malmaison.fc-templates"
export VCD_SITE="fca.rueil-malmaison.SE.fc-templates"
export VCD_SITE="fca.val-de-reuil.fc-templates"
export VCD_SITE="fca.val-de-reuil.ocb-cssa"
export VCD_SITE="fco.val-de-reuil"
'
