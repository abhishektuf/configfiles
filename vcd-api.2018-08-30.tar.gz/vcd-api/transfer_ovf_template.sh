#!/bin/bash


template_name=$(whiptail --noitem --title "Choose a template" --menu "" 25 80 18 $(
+()
{ 
    echo "$1" "$1"
} 
. template.list) 3>&1 1>&2 2>&3)


+()
{
    if [ "$template_name" = "$1" ]
    then
        template_name="$1"
        vapp_template_name="$2"

        if [[ -z "$vapp_template_name" ]]
        then
            vapp_template_name="$template_name"
        fi

        . "$(dirname "$0")/fcv3.lib"

        echo "template_name      [$template_name]"
        echo "vapp_template_name [$vapp_template_name]"

        transfer_ovf_template "$template_name" "$vapp_template_name"
    fi
}
. template.list
