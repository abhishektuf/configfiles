#!/bin/bash
#
# Interactive script to add a VM from a vApp-template into an existing vApp
# and connect its 2 network interfaces to selected networks

main()
{
    . "$(dirname "$0")/fcv3.lib"

    source_catalog_info="$(ask_for_catalog "Choose the source Catalog...")"
    check_entry "$source_catalog_info"

    source_catalog_name=$(echo "$source_catalog_info" | cut -d'|' -f1)
    source_catalog_id=$(echo "$source_catalog_info" | cut -d'|' -f2)

    source_vapp_template_name="$(ask_for_vapp_template "Choose the source vApp template..." "$source_catalog_id")"
    check_entry "$source_vapp_template_name"

    target_vapp_info="$(ask_for_vapp "Choose the destination vApp...")"
    check_entry "$target_vapp_info"

    target_vapp_name=$(echo "$target_vapp_info" | cut -d'|' -f1)
    target_vapp_id=$(echo "$target_vapp_info" | cut -d'|' -f2)

    yes_no "Do you really want to add The template [$source_vapp_template_name] from catalog [$source_catalog_name] into the vApp [$target_vapp_name] ?" || exit 1

    add_vm_from_template_into_existing_vapp $source_vapp_template_name $source_catalog_name $target_vapp_name $target_vapp_id

    target_vm_id=$(get_vm_id_by_name "$target_vapp_id" "$source_vapp_template_name")
    echo "target_vm_id [$target_vm_id]"
#    setup_vm_nic "$target_vm_id"
    network_interface_0_name="$(ask_for_network "Select a network for interface 0" "$target_vapp_id")"
    check_entry "$network_interface_0_name"
    network_interface_1_name="$(ask_for_network "Select a network for interface 1" "$target_vapp_id")"
    check_entry "$network_interface_1_name"
    
    connect_vm_interfaces_to_network "$target_vm_id" "$network_interface_0_name" "$network_interface_1_name"
}

main
