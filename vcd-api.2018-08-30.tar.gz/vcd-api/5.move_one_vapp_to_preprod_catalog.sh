#!/bin/bash

template_name=$(whiptail --noitem --title "Choose a template" --menu "" 25 80 18 $(
+()
{
    echo "$1" "$1"
}
. template.list) 3>&1 1>&2 2>&3)


+()
{
    if [ "$template_name" = "$1" ]
    then
        template_name="$1"
        vapp_name="$2"
        computer_name="$3"
        guest_os_type="$4"
        postconf_type="$5"
        preprod_catalog="$6"

        . "$(dirname "$0")/fcv3.lib"

        move_vapp_to_catalog "$vapp_name" "$preprod_catalog"
    fi
}
. template.list
