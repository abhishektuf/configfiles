#!/bin/bash
#
# Test an api command

main()
{
    resource="$1"

    if [ -z "$1" ]; then
        echo "Please provide an api ressource..."
        echo "Example: vApp/vm-1d1cfa87-3222-4202-8868-479d6e917d32"
        exit 1
    fi

    . "$(dirname "$0")/fcv3.lib"
    _get "api/$resource" > requested-resource.xml

    cat requested-resource.xml

    title_echo "The xml representation of the ressource has been stored in $(pwd)/requested-resource.xml"
}

main "$1"
