#!/bin/bash
#
# Interactive script to add a VM from a vApp-template into an existing vApp
# and connect its 2 network interfaces to selected networks

main()
{
    . "$(dirname "$0")/fcv3.lib"

    source_catalog_info="$(ask_for_catalog "Choose the source Catalog...")"
    check_entry "$source_catalog_info"

    source_catalog_name=$(echo "$source_catalog_info" | cut -d'|' -f1)
    source_catalog_id=$(echo "$source_catalog_info" | cut -d'|' -f2)

    source_vapp_template_name="$(ask_for_vapp_template "Choose the source vApp template..." "$source_catalog_id")"
    check_entry "$source_vapp_template_name"

    network_name="$(ask_for_vdc_network "Select a network to connect inside the vApp" "$VDC_ID")"
    check_entry "$network_name"

    yes_no "Create a new vApp based on [$source_vapp_template_name] from [$source_catalog_name] catalog and connect it to the [$network_name] network?" || exit 1

    target_vm_name="$source_vapp_template_name"

    instantiate_vapp_from_template "$source_vapp_template_name" "$target_vm_name" "$source_catalog_name" "Updated on $(date)."

    target_vapp_id="$(get_vapp_id_by_name "$target_vm_name")"
    target_vm_id="$(get_first_vm_id_in_vapp "$target_vapp_id")"

    poweroff_vapp "$target_vapp_id"

    echo "Waiting 30 seconds..."
    sleep 30

    update_guest_customization "$target_vm_id" "toto"
    setup_org_network "$target_vapp_id" "$network_name"

    network_interface_0_name="$(ask_for_network "Select a network for interface 0" "vapp-$target_vapp_id")"
    check_entry "$network_interface_0_name"
    network_interface_1_name="$network_interface_0_name"
    check_entry "$network_interface_1_name"

    connect_vm_interfaces_to_network "vm-$target_vm_id" "$network_interface_0_name" "$network_interface_1_name"
}

main
