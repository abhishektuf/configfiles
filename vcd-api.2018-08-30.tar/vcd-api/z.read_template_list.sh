
+()
{(	
    template_name="$1"
    vapp_name="$2"
    computer_name="$3"
    guest_os_type="$4"
    postconf_type="$5"
    prod_catalog="$6"
    
    echo "template_name: $template_name"
    echo "vapp_name:     $vapp_name"
    echo "computer_name: $computer_name"
    echo "guest_os_type: $guest_os_type"
    echo "postconf_type: $postconf_type"
    echo "prod_catalog:  $prod_catalog"
    echo
)}

. template.list
