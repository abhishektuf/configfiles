#!/bin/bash


. "$(dirname "$0")/fcv3.lib"

catalog_items="$(list_catalog_item "$CATALOG_ID")"
vapp_templates=""

for item in $catalog_items ; do
    echo "> catalog item id [$item]"
    vapp_template_id="$(get_vapp_template_id "$item")"
    vapp_template_name="$(get_vapp_template_name "$vapp_template_id")"
#    if [[ -n "$vapp_template_name" ]] ; then
        echo "  vApp name [$vapp_template_name]   vApp id [$vapp_template_id ]"
        vapp_templates="$vapp_templates\n$vapp_template_name $vapp_template_id"
#    fi
    sleep 1
done

echo -e "$vapp_templates"

