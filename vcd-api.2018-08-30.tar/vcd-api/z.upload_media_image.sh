#!/bin/bash


. "$(dirname "$0")/fcv3.lib"

usage()
{
    echo "Usage:   $0 media_file"
    echo "Example: $0 /tmp/media-file.iso" 
}

upload_media()
{(
    # Ref: https://pubs.vmware.com/vcd-55/index.jsp#com.vmware.vcloud.api.doc_55/GUID-4DAFB730-9C5B-406E-8348-E42B9036B49A.html

    media_file="$1"

    if [ ! -f "$media_file" ]
    then
        warning_echo "Error: Missing media file." 1>&2
        usage
        exit 1
    fi


    media_name="$(basename $media_file)"
    media_size="$(stat --format='%s' $media_file)"
    media_description="Send via API"

    (
        echo "Media File:          [$media_file]"
        echo "Media Size:          [$media_size]"
        echo "Media Name:          [$media_name]"
        echo "Media Description:   [$media_description]"
    ) | debug_echo


    title_echo "UPLOADING MEDIA..."

    echo '<?xml version="1.0" encoding="UTF-8"?>
<Media
   xmlns="http://www.vmware.com/vcloud/v1.5"
   name="'"$media_name"'"
   size="'"$media_size"'"
   imageType="iso"
   >
   <Description>'"$media_description"'</Description>
</Media>' > "$REQ_FILE"

    # Get media id
    _post "api/catalog/$CATALOG_ID/action/upload" "$REQ_FILE" "Content-Type: application/vnd.vmware.vcloud.media+xml" > "$RES_FILE"
    media_id="$(cat "$RES_FILE" | grep "<Entity " | tr '" \r\t' '\n' | grep 'api/media' | sed -e "s,$VCD_API_URL/api/media/,,g")"

    (
        echo "Media Id:            [$media_id]"
    ) | debug_echo
   
    # Get media transfer link
    _get "api/media/$media_id" > "$RES_FILE"
    media_transfer_link="$(cat "$RES_FILE" | grep "upload:default" | tr '" \r\t' '\n' | grep "^http" | sed -e "s,$VCD_API_URL/transfer/,,g")"

    (
        echo "Media Transfer Link: [$media_transfer_link]"
    ) | debug_echo

    # Upload media contents
    _put "transfer/$media_transfer_link" "$media_file"
)}

upload_media "$1"

