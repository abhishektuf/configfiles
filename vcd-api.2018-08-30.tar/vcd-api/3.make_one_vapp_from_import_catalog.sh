#!/bin/bash

template_name=$(whiptail --noitem --title "Choose a template" --menu "" 25 80 18 $(
+()
{
    echo "$1" "$1"
}
. template.list) 3>&1 1>&2 2>&3)



+()
{
    if [ "$template_name" = "$1" ]
    then
        template_name="$1"
        vapp_name="$2"
        computer_name="$3"
        guest_os_type="$4"
        postconf_type="$5"
        prod_catalog="$6"
        postconf_path="./postconf_$(echo "$postconf_type" | tr '[A-Z]' '[a-z]')_fcv3.sh"

        . "$(dirname "$0")/fcv3.lib"

        make_vapp "$template_name" "$vapp_name" "$computer_name" "$guest_os_type" "$postconf_path" "obs-org-adm"
    fi
}

. template.list
